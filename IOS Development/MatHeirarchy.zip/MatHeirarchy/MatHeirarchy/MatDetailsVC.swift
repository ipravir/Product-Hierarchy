//
//  MatDetailsVC.swift
//  MatHeirarchy
//
//  Created by user on 15/05/23.
//

import Foundation
import UIKit
import SAPFiori

class MatDetailsVC: UIViewController {

    @IBOutlet weak var bttnLeft: UIButton!
    @IBOutlet weak var oMatImage: UIImageView!
    @IBOutlet weak var lblMatDscr: UILabel!
    @IBOutlet weak var lblMatNo: UILabel!
    @IBOutlet weak var bttnRight: UIButton!
    var iClickCount: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        iClickCount = 0
        bttnLeft.isHidden = true
        if iMaterialInfo.count == 1{
            bttnRight.isHidden = true
        }
        self.DisplayMaterialInfoandImage()
        
    }
    
    @IBAction func bttnRightTouch(_ sender: Any) {
        iClickCount = iClickCount + 1
        self.DisplayMaterialInfoandImage()
        bttnLeft.isHidden = false
        if iMaterialInfo.count == ( iClickCount + 1 ){
            bttnRight.isHidden = true
        }
    }
    @IBAction func bttnLefttouch(_ sender: Any) {
        iClickCount = iClickCount - 1
        self.DisplayMaterialInfoandImage()
        if iClickCount ==  0{
            bttnLeft.isHidden = true
        }
        if iMaterialInfo.count > ( iClickCount + 1 ){
            bttnRight.isHidden = false
        }
    }
    
    func DisplayMaterialInfoandImage() {
        lblMatNo.text = iMaterialInfo[iClickCount].Matnr
        lblMatDscr.text = iMaterialInfo[iClickCount].Maktx
        if let imageData = Data(base64Encoded: self.getMaterialImage(sMatnr: iMaterialInfo[iClickCount].Matnr)) {
            if let image = UIImage(data: imageData) {
                // Use the image to display it in an image view or any other UI element
                oMatImage.image = image
                oMatImage.layer.borderColor = #colorLiteral(red: 0.2465660274, green: 0.3182864785, blue: 0.380423218, alpha: 1) //UIColor.blue.cgColor
                oMatImage.layer.cornerRadius = 20
                oMatImage.layer.borderWidth = 5.0
                
            } else {
                oMatImage.image = nil
            }
        } else {
            oMatImage.image = nil
        }
    }
    
    @IBAction func bttnCloseTouch(_ sender: Any) {
        self.dismiss(animated: true)
    }
    func getMaterialImage(sMatnr:String) -> String {
        var sMatImage:String = ""
        let filterMatnr = iMaterialImage.filter { $0.Name == sMatnr }
        if let sMatsImage = filterMatnr.first {
            sMatImage = sMatsImage.Suffix
            return sMatImage
        } else {
            return sMatImage
        }
    }
    
    @IBAction func actionDispayAlMats(_ sender: Any) {
        bDisplayAllMatsClick = true
        self.dismiss(animated: true)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "displayAllMaterialsinTable"), object: nil, userInfo: nil)
    }
    
}

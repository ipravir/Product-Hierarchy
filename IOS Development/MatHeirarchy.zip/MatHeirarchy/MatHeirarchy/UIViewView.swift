//
//  UIViewView.swift
//  MatHeirarchy
//
//  Created by user on 15/05/23.
//

import UIKit

class UIViewView: UIView {

    override func awakeFromNib() {
        self.layer.cornerRadius = 20
    }

}

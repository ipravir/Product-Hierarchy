//
//  clStackView.swift
//  MatHeirarchy
//
//  Created by user on 15/05/23.
//

import UIKit

class clStackView: UIStackView {

    override func awakeFromNib() {
        self.layer.cornerRadius = 20
    }

}

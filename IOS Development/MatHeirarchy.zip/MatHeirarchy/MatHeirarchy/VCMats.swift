//
//  VCMats.swift
//  MatHeirarchy
//
//  Created by user on 20/05/23.
//

import UIKit
import SAPFiori

class VCMats: UIViewController, UITableViewDelegate, UITableViewDataSource {
    let materials = "Materials"
    @IBOutlet weak var oMaterials: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        oMaterials.estimatedRowHeight = 80
        oMaterials.rowHeight  = UITableView.automaticDimension
        
        oMaterials.delegate = self
        oMaterials.dataSource = self
        
        oMaterials.register(FUIObjectTableViewCell.self, forCellReuseIdentifier: materials)
        
//        let leftSwipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(handleLeftSwipe))
//        leftSwipeGesture.direction = .left
//        oMaterials.addGestureRecognizer(leftSwipeGesture)
        
    }
    

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return iMaterialInfo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let oFCell = tableView.dequeueReusableCell(withIdentifier: materials,
                                                   for: indexPath as IndexPath) as! FUIObjectTableViewCell
        oFCell.headlineText = iMaterialInfo[indexPath.row].Matnr
        oFCell.footnoteText = iMaterialInfo[indexPath.row].Maktx
        oFCell.descriptionText = iMaterialInfo[indexPath.row].Maktx
        
        if let imageData = Data(base64Encoded: self.getMaterialImage(sMatnr: iMaterialInfo[indexPath.row].Matnr)) {
            if let image = UIImage(data: imageData) {
                // Use the image to display it in an image view or any other UI element
                oFCell.detailImage = image
                
            } else {
                oFCell.detailImage = nil
            }
        } else {
            oFCell.detailImage = nil
        }

        oFCell.accessoryType = .disclosureIndicator
        oFCell.backgroundColor = #colorLiteral(red: 0.6516525745, green: 0.875934422, blue: 1, alpha: 1)
        oFCell.splitPercent = CGFloat(0.3)
        
        // Add swipe gesture recognizer to the cell
        let leftSwipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(leftHandleSwipe(gesture:)))
        leftSwipeGesture.direction = .right
        oFCell.addGestureRecognizer(leftSwipeGesture)
        
        return oFCell
    }
    
    @objc func leftHandleSwipe(gesture: UITapGestureRecognizer) {
        // Dismiss the view controller when left swipe is detected
        dismiss(animated: true, completion: nil)
    }
    
    func getMaterialImage(sMatnr:String) -> String {
        var sMatImage:String = ""
        let filterMatnr = iMaterialImage.filter { $0.Name == sMatnr }
        if let sMatsImage = filterMatnr.first {
            sMatImage = sMatsImage.Suffix
            return sMatImage
        } else {
            return sMatImage
        }
    }


}

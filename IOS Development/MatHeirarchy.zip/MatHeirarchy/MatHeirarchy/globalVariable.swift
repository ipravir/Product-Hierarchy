//
//  globalVariable.swift
//  MatHeirarchy
//
//  Created by user on 15/05/23.
//

import Foundation
import SAPOData

struct MatHierarchy{
    var NImage:String
    var Isfolder:Bool
    var Text:String
    var MatInfo:Int
}

struct ParentSel {
    var NodeKey:String
}

struct MaterialsInfo {
    var Matnr:String
    var Maktx:String
    var Prdha:String
}

struct MaterialImage {
    var Name:String
    var Suffix:String
    var Descript:String
}

var iMatHierarchy:[MatHierarchy] = []

var iParentSel:[ParentSel] = []

var iMaterialInfo:[MaterialsInfo] = []

var iMaterialImage:[MaterialImage] = []

let oDataProvider = OnlineODataProvider(serviceName: "heirarchySet", serviceRoot: "http://{APPLICATION Server : PORT NUMBER}/sap/opu/odata/sap/ZMAT_HEIR_SRV/")

var bDisplayAllMatsClick: Bool = false

//
//  ViewController.swift
//  MatHeirarchy
//
//  Created by user on 07.05.2023.
//

import UIKit
import SAPCommon
import SAPFiori
import SAPOData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var oHierarchy: UITableView!
    let objectCellId = "ProductCellID"
    override func viewDidLoad() {
        super.viewDidLoad()
        
        oDataProvider.login(username: "SAP-USER-ID", password: "SAP_PASSWORD")
        oDataProvider.serviceOptions.checkVersion = false
        
        iMatHierarchy = self.getParents()
        
        //        oHierarchy.register(FUIGridTableViewSummaryFooter.self, forHeaderFooterViewReuseIdentifier: FUIGridTableViewSummaryFooter.reuseIdentifier)
        //        oHierarchy.register(FUIGridTableViewHeader.self, forHeaderFooterViewReuseIdentifier: FUIGridTableViewHeader.reuseIdentifier)
        oHierarchy.register(FUIGridTableViewCell.self, forCellReuseIdentifier: FUIGridTableViewCell.reuseIdentifier)
        oHierarchy.delegate = self
        oHierarchy.dataSource = self
        
        oHierarchy.estimatedRowHeight = 80
        oHierarchy.rowHeight = UITableView.automaticDimension
        oHierarchy.register(FUIObjectTableViewCell.self, forCellReuseIdentifier: objectCellId)
        
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(gesture:)))
        doubleTapGesture.numberOfTapsRequired = 2
        oHierarchy.addGestureRecognizer(doubleTapGesture)
        
        iParentSel = []
        
        NotificationCenter.default.addObserver(self, selector: #selector(displayAllMaterialsinTable), name: NSNotification.Name(rawValue: "displayAllMaterialsinTable"), object: nil)
    }
    
    @objc func displayAllMaterialsinTable(){
        guard let oAllMaterials = self.storyboard?.instantiateViewController(identifier: "VCMats") else {return}
        oAllMaterials.modalPresentationStyle = .fullScreen
        self.present(oAllMaterials, animated: true, completion: nil)
    }
    
    func getParents() -> [MatHierarchy] {
        var ilMatHierarchy:[MatHierarchy] = []
        let oData = OnlineDataService(provider: oDataProvider)
        if oData.hasMetadata == false || oData.hasMetadata == true{
            do{
                try oData.loadMetadata()
                let esMatParent = oData.entitySet(withName: "heirarchySet")
                let etMatHierarchy = esMatParent.entityType
                
                let oQuery = DataQuery().selectAll().from(esMatParent)
                
                let lvNImage = etMatHierarchy.property(withName: "NImage")
                let lvIsfolder = etMatHierarchy.property(withName: "Isfolder")
                let lvText = etMatHierarchy.property(withName: "Text")
                let lvDragdropid = etMatHierarchy.property(withName: "Dragdropid")
                
                do{
                    let oResult = try oData.executeQuery(oQuery).entityList()
                    for item in oResult.toArray(){
                        let sMatHierarchy = MatHierarchy(NImage: lvNImage.stringValue(from: item),
                                                         Isfolder: lvIsfolder.booleanValue(from: item),
                                                         Text: lvText.stringValue(from: item),
                                                         MatInfo: lvDragdropid.shortValue(from: item))
                        ilMatHierarchy.append(sMatHierarchy)
                    }
                }
            } catch {
                
            }
        }
        iParentSel = []
        return ilMatHierarchy
    }
    
    func getChilds(NodeKey: String) -> [MatHierarchy] {
        var ilMatHierarchy:[MatHierarchy] = []
        let oData = OnlineDataService(provider: oDataProvider)
        if oData.hasMetadata == true{
            do{
                try oData.loadMetadata()
                let esMatParent = oData.entitySet(withName: "heirarchySet")
                let etMatHierarchy = esMatParent.entityType
                
                let lvNImage = etMatHierarchy.property(withName: "NImage")
                let lvIsfolder = etMatHierarchy.property(withName: "Isfolder")
                let lvText = etMatHierarchy.property(withName: "Text")
                let lvDragdropid = etMatHierarchy.property(withName: "Dragdropid")
                
                let oQuery = DataQuery().selectAll().from(esMatParent).filter(lvNImage.equal(NodeKey))
                
                do{
                    let oResult = try oData.executeQuery(oQuery).entityList()
                    for item in oResult.toArray(){
                        let sMatHierarchy = MatHierarchy(NImage: lvNImage.stringValue(from: item),
                                                         Isfolder: lvIsfolder.booleanValue(from: item),
                                                         Text: lvText.stringValue(from: item),
                                                         MatInfo: lvDragdropid.shortValue(from: item))
                        ilMatHierarchy.append(sMatHierarchy)
                    }
                }
            } catch {
                
            }
        }
        var lvFound:Bool = false
        for each in iParentSel{
            if each.NodeKey == NodeKey{
                lvFound = true
            }
        }
        if lvFound == false{
            iParentSel.append(ParentSel(NodeKey: NodeKey))
        }
        return ilMatHierarchy
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return iMatHierarchy.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let oFCell = tableView.dequeueReusableCell(withIdentifier: objectCellId,
                                                   for: indexPath as IndexPath) as! FUIObjectTableViewCell
        oFCell.headlineText = iMatHierarchy[indexPath.row].Text
        oFCell.footnoteText = "No of Material Created :\(iMatHierarchy[indexPath.row].MatInfo)"
        oFCell.descriptionText = "No of Material Created :\(iMatHierarchy[indexPath.row].MatInfo)"
        oFCell.accessoryType = .none
        oFCell.backgroundColor = #colorLiteral(red: 0.6516525745, green: 0.875934422, blue: 1, alpha: 1)
        oFCell.splitPercent = CGFloat(0.3)
        return oFCell
        
    }
    
    @objc func handleDoubleTap(gesture: UITapGestureRecognizer) {
            if gesture.state == .ended {
                // Get the cell that was long pressed
                let SelPoint = gesture.location(in: oHierarchy)
                if let indexPath = oHierarchy.indexPathForRow(at: SelPoint){
                    iMaterialImage = self.getMaterialsImages(nodeKey: iMatHierarchy[indexPath.row].NImage)
                    iMaterialInfo = self.getMaterialsOfSelectedNode(nodeKey: iMatHierarchy[indexPath.row].NImage)
                    if iMaterialInfo.count != 0{
                        let oMatInfo = MatDetailsVC()
                        oMatInfo.modalPresentationStyle = .custom
                        self.present(oMatInfo, animated: true, completion: nil)
                    }
                }
            }
        }

    
    @objc private func handleLongPressGesture(sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            // Get the cell that was long pressed
            if let cell = sender.view as? UITableViewCell {
                // Perform actions on the cell as required
                if let indexPath = oHierarchy.indexPath(for: cell) {
                    iMaterialImage = self.getMaterialsImages(nodeKey: iMatHierarchy[indexPath.row].NImage)
                    iMaterialInfo = self.getMaterialsOfSelectedNode(nodeKey: iMatHierarchy[indexPath.row].NImage)
                    if iMaterialInfo.count != 0{
                        let oMatInfo = MatDetailsVC()
                        oMatInfo.modalPresentationStyle = .custom
                        self.present(oMatInfo, animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        if iParentSel.count == 0{
            return nil
        } else {
            let rightAction = UIContextualAction(style: .normal, title: "Right Action") { (action, view, completion) in }
            // Create an icon for the swipe action
            if iParentSel.count > 1{
                iMatHierarchy = self.getChilds(NodeKey: iParentSel[iParentSel.count - 2].NodeKey)
                let lvDelIndex = iParentSel.count - 1
                iParentSel.remove(at: lvDelIndex)
            } else {
                iMatHierarchy = self.getParents()
                iParentSel = []
            }
            self.oHierarchy.reloadData()
            self.oHierarchy.dataSource = self
            let iconImage = UIImage(systemName: "arrowshape.turn.up.backward.2.fill")
            rightAction.image = iconImage
            rightAction.backgroundColor =  .blue
            let configuration = UISwipeActionsConfiguration(actions: [rightAction])
            return configuration
        }
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        if iMatHierarchy[indexPath.row].Isfolder == true{
            let updateAction = UIContextualAction(style: .normal, title: "Childs", handler: { (action, view, completionHandler) in  })
            iMatHierarchy = self.getChilds(NodeKey: iMatHierarchy[indexPath.row].NImage)
            self.oHierarchy.reloadData()
            let iconImage = UIImage(systemName: "text.line.first.and.arrowtriangle.forward")
            updateAction.image = iconImage
            self.oHierarchy.dataSource = self
            updateAction.backgroundColor = #colorLiteral(red: 0.1341861486, green: 0.4280691445, blue: 0.4506213069, alpha: 1)
            let configuration = UISwipeActionsConfiguration(actions: [updateAction])
            return configuration
        } else {
            return nil
        }
    }
    
    func getMaterialsOfSelectedNode(nodeKey:String) -> [MaterialsInfo] {
        var ltMatInfo:[MaterialsInfo] = []
        
        let oData = OnlineDataService(provider: oDataProvider)
        if oData.hasMetadata == true{
            do{
                try oData.loadMetadata()
                let esMatInfo = oData.entitySet(withName: "matsinfoSet")
                let etMatInfo = esMatInfo.entityType
                let lvMatnr = etMatInfo.property(withName: "Matnr")
                let lvMaktx = etMatInfo.property(withName: "Maktx")
                let lvPrdha = etMatInfo.property(withName: "Prdha")
                let oQuery = DataQuery().selectAll().from(esMatInfo).filter(lvPrdha.equal(nodeKey))
                do{
                    let oResult = try oData.executeQuery(oQuery).entityList()
                    for item in oResult.toArray(){
                        let sMatInfo = MaterialsInfo(Matnr: lvMatnr.stringValue(from: item),
                                                     Maktx: lvMaktx.stringValue(from: item),
                                                     Prdha: lvPrdha.stringValue(from: item))
                        ltMatInfo.append(sMatInfo)
                    }
                }
            } catch {
                
            }
        }
        return ltMatInfo
    }
    
    func getMaterialsImages(nodeKey:String) -> [MaterialImage] {
        var ltMatImage:[MaterialImage] = []
        
        let oData = OnlineDataService(provider: oDataProvider)
        if oData.hasMetadata == true{
            do{
                try oData.loadMetadata()
                let esMatImage = oData.entitySet(withName: "matimgSet")
                let etMatImage = esMatImage.entityType
                
                let lvName = etMatImage.property(withName: "Name")
                let lvDescript = etMatImage.property(withName: "Descript")
                let lvSuffix = etMatImage.property(withName: "Suffix")
                
                let oQuery = DataQuery().selectAll().from(esMatImage).filter(lvName.equal(nodeKey))
                
                do{
                    let oResult = try oData.executeQuery(oQuery).entityList()
                    for item in oResult.toArray(){
                        let sMatImage = MaterialImage(Name: lvName.stringValue(from: item),
                                                      Suffix: lvSuffix.stringValue(from: item),
                                                      Descript: lvDescript.stringValue(from: item))
                        ltMatImage.append(sMatImage)
                    }
                }
            } catch {
                
            }
        }
        return ltMatImage
    }
    
}

